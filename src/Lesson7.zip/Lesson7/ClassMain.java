package Lesson7;

class ClassMain{
    public static void main(String[] args) {
        new MainWindow(500,500);
    }
}
